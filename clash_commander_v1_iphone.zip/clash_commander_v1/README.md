# Clash Commander v1.0

An iPhone-friendly, installable web-app prototype for manual Clash Royale match tracking and deck-specific coaching.

## Included
- Your eight-card deck: Evolution Witch, Evolution Electro Dragon, Elixir Golem, Arrows, Tesla, Skeleton King, Skeletons, Fireball.
- Manual elixir estimates for both players.
- Editable starting hand and simulated four-card cycle.
- Opponent card checklist.
- Match timer, undo, reset, and heuristic recommendations.
- Responsive layout and basic offline caching when hosted over HTTPS.

## Run locally
Open `index.html` in a modern browser. Some PWA features require HTTPS.

## Install on iPhone
1. Host this folder on an HTTPS static host (for example, GitHub Pages or another static web host).
2. Open the hosted URL in Safari on your iPhone.
3. Tap Share -> Add to Home Screen -> Add.
4. Launch Clash Commander from the Home Screen.

## Important
This prototype does not connect to Clash Royale, capture the game screen, inspect game memory, automate taps, or guarantee wins. Inputs are manual and recommendations are heuristics, not perfect game-solving. It is an unofficial fan-made tool and is not affiliated with Supercell.

## Next development steps
- Add a real card/arena database and matchup notes.
- Add replay upload and frame-by-frame analysis where legally and technically supported.
- Improve elixir/cycle estimation and validate recommendations against recorded match data.
- Add automated tests for decision logic.
